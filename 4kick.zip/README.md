# DnA Bot LinePy
Account :
1 Admin,
11 Bot Assist,
Total : 12

Cara Instal di termux: 
- pkg install python3 
- pkg install pip3 
- pkg install git 
- git clone https://github.com/Dee-n-a/Rin
- pip3 install rsa 
- pip3 install thrift==0.11.0 
- pip3 install humanfriendly
- pip3 install requests 
- cd Rin
- python3 dna.py


Cara Install Self ProtectPy3 di c9: 
- apt update 
- apt install git 
- apt install python3 
- apt install pip3==python3 
- pip3 install rsa 
- pip3 install thrift 
- pip3 install requests 
- pip3 install humanfriendly 
- git clone https://github.com/Dee-n-a/Rin
- cd protectpy3 
- python3 protectpy3.py 


Credit By Dee 
- Add My ID LINE : 〘 https://line.me/ti/p/ppgIZ0JLDW 〙



Thx To : 
- Ghost Team
- BotEater
- HELLO-WORLD
- Nadya Sutjiadi
- iiipuuul
- Eva wongmu
- Inne Febriani
